SUMBER LATEX LAPORAN SMART PARCEL LOCKER
WI1102 | Kelas 31 | Kelompok 12
Versi final: 19 Oktober 2026

Berkas utama: WI1102_ProjekI_31_12.tex
Gambar: assets/
Lampiran kode: code/WI1102_ProjekI_31_12.py

Laporan menggunakan A4, Times New Roman 12, Courier New 12 untuk kode,
dan spasi tunggal sesuai brief WI1102 halaman 11. Bagian utama tegak;
lampiran kode mendatar. Daftar isi, nomor tabel/gambar, dan sitasi
dikelola oleh LaTeX. Daftar pustaka berada di dalam berkas .tex.

CARA KOMPILASI
1. Ekstrak seluruh folder; pertahankan assets/ dan code/ di lokasi yang sama
   dengan .tex. Gunakan XeLaTeX atau Tectonic, bukan pdfLaTeX.
2. Pastikan font Times New Roman dan Courier New sudah terpasang.
   Font berlisensi tersebut tidak disertakan dalam paket ini.
3. Jalankan dari folder ini:

   tectonic WI1102_ProjekI_31_12.tex

   Alternatif bila memakai distribusi TeX dengan XeLaTeX:

   xelatex -interaction=nonstopmode -halt-on-error WI1102_ProjekI_31_12.tex
   xelatex -interaction=nonstopmode -halt-on-error WI1102_ProjekI_31_12.tex

   Tectonic mengunduh paket yang dibutuhkan saat kompilasi pertama.

Jika memakai Overleaf, pilih compiler XeLaTeX dan sediakan font yang
sesuai melalui instalasi atau berkas font yang Anda berhak gunakan.
Jangan mengganti font tanpa mencocokkan kembali dengan ketentuan tugas.

MENYUNTING
- Edit isi di .tex; simpan teks sebagai UTF-8.
- Gambar di assets/ dapat diganti dengan tetap mempertahankan nama berkas.
- Lampiran membaca kode langsung melalui VerbatimInput. Bila kode berubah,
  sesuaikan nomor baris yang dibahas dalam laporan serta potongan lampiran,
  jalankan ulang pengujian, lalu kompilasi dan periksa seluruh halaman.
- PDF utama adalah hasil LaTeX. DOCX pada paket utama adalah versi sunting
  pendamping; perubahan pada DOCX tidak otomatis memperbarui sumber LaTeX.

KODE YANG DISERTAKAN
194 baris; SHA-256:
bc986a4a9cf8564d3b2ed7a305c99e4854f5eb2dd9b54e5a72a665ccf521cb21
Kode ini identik dengan versi yang lulus 44 skenario perilaku dan
262.144 pemeriksaan blok alokasi. Pengujian lengkap tersedia pada folder
Pengujian/ di Paket_ProjekI_Kelompok12.zip.

VIDEO
https://drive.google.com/file/d/1F4LFyakFaFF9PxFglL3AjJ7lagQiUMqt/view
Durasi terverifikasi 14 menit 30,17 detik. Akses tautan diperiksa pada
19 Oktober 2026. Laporan ini belum dikumpulkan melalui sistem perkuliahan.
